"""Safe, deterministic intent classifier for the Clinical Operations Agent demo.

This module classifies text only. It never executes tools, accesses a database,
or performs an operational action. All outputs are constrained to INTENT_CATALOGUE.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
import re
from typing import Any

INTENT_CATALOGUE = {
    "book_appointment": {"action": "book_appointment", "approval": True, "required": ["patient_id"]},
    "reschedule_appointment": {"action": "reschedule_appointment", "approval": True, "required": ["appointment_id"]},
    "cancel_appointment": {"action": "cancel_appointment", "approval": True, "required": ["appointment_id"]},
    "search_slots": {"action": "search_slots", "approval": False, "required": ["specialty"]},
    "check_referral": {"action": "check_referral", "approval": False, "required": ["referral_id"]},
    "request_documents": {"action": "request_documents", "approval": True, "required": ["referral_id"]},
    "check_authorization": {"action": "check_authorization", "approval": False, "required": ["authorization_id"]},
    "sla_watch": {"action": "escalate_authorization", "approval": True, "required": []},
    "get_appointment": {"action": "read", "approval": False, "required": ["appointment_id"]},
    "unknown": {"action": "read", "approval": False, "required": []},
}
THRESHOLDS = {"execute": 0.80, "clarify": 0.55}

@dataclass
class Classification:
    intent: str
    action: str
    confidence: float
    entities: dict[str, Any] = field(default_factory=dict)
    needs_human_approval: bool = False
    decision: str = "clarify"
    missing_entities: list[str] = field(default_factory=list)
    alternatives: list[dict[str, Any]] = field(default_factory=list)
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

_PATTERNS = [
    ("cancel_appointment", 0.94, [r"\bcancel\b.*\bappointment\b", r"\bcancel appointment\b"]),
    ("reschedule_appointment", 0.94, [r"\breschedul", r"\bmove\b.*\bappointment\b", r"\bchange\b.*\bappointment\b"]),
    ("book_appointment", 0.94, [r"\bbook\b.*\bappointment\b", r"\bschedule\b.*\bappointment\b", r"\bmake\b.*\bappointment\b"]),
    ("search_slots", 0.91, [r"\bavailable (?:appointment )?slots?\b", r"\bfind\b.*\bappointment times?\b", r"\bavailability\b"]),
    ("request_documents", 0.91, [r"\brequest\b.*\bdocuments?\b", r"\bsend\b.*\b(document|records?)\b", r"\bmissing documents?\b"]),
    ("check_referral", 0.92, [r"\b(check|show|get|what is)\b.*\breferral\b", r"\breferral status\b"]),
    ("check_authorization", 0.92, [r"\b(check|show|get|what is)\b.*\b(authori[sz]ation|prior auth)\b", r"\b(authori[sz]ation|prior auth)\b.*\bstatus\b"]),
    ("sla_watch", 0.88, [r"\b(sla|overdue|past due|deadline|due soon)\b"]),
    ("get_appointment", 0.86, [r"\b(show|get|check|look up)\b.*\bappointment\b"]),
]

def _extract_entities(text: str) -> dict[str, Any]:
    e: dict[str, Any] = {}
    id_patterns = {
        "patient_id": r"\bPT-\d{3,}\b",
        "referral_id": r"\bRF-\d{3,}\b",
        "authorization_id": r"\bPA-\d{3,}\b",
        "appointment_id": r"\bAP-\d{3,}\b",
    }
    for key, pattern in id_patterns.items():
        m = re.search(pattern, text, re.I)
        if m:
            e[key] = m.group(0).upper()

    specialties = {
        "cardiology": "Cardiology", "dermatology": "Dermatology",
        "neurology": "Neurology", "orthopedics": "Orthopedics",
        "orthopaedics": "Orthopedics", "primary care": "Primary Care",
        "oncology": "Oncology", "gastroenterology": "Gastroenterology",
        "ophthalmology": "Ophthalmology",
    }
    lower = text.lower()
    for phrase, label in specialties.items():
        if re.search(r"\b" + re.escape(phrase) + r"\b", lower):
            e["specialty"] = label
            break

    insurers = ["Northstar Health", "Evergreen Mutual"]
    for insurer in insurers:
        if insurer.lower() in lower:
            e["insurer"] = insurer
            break

    if re.search(r"\b(urgent|asap|immediately|overdue|past due)\b", lower):
        e["urgency"] = "urgent"
    else:
        e["urgency"] = "routine"

    # Capture simple explicit dates/times without guessing a timezone.
    date_match = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", text)
    if date_match:
        try:
            datetime.strptime(date_match.group(1), "%Y-%m-%d")
            e["requested_date"] = date_match.group(1)
        except ValueError:
            pass
    time_match = re.search(r"\b(0?[1-9]|1[0-2])(?::([0-5]\d))?\s*(am|pm)\b", lower)
    if time_match:
        hour = int(time_match.group(1)) % 12
        if time_match.group(3) == "pm":
            hour += 12
        e["requested_time"] = f"{hour:02d}:{time_match.group(2) or '00'}"
    return e

def classify_intent(text: str) -> Classification:
    """Return a constrained classification; low-confidence/ambiguous requests clarify."""
    if not isinstance(text, str) or not text.strip():
        return Classification("unknown", "read", 0.0, decision="clarify", reason="Empty request")
    if len(text) > 2000:
        return Classification("unknown", "read", 0.0, decision="clarify", reason="Request exceeds 2000 characters")

    lower = text.lower().strip()
    entities = _extract_entities(text)

    # Negated requests must not be treated as authorization to act.
    if re.search(r"\b(do not|don't|dont|never|not)\b.{0,35}\b(book|schedule|cancel|reschedule|send|request)\b", lower):
        return Classification("unknown", "read", 0.30, entities, decision="clarify",
                              reason="The request contains a negated action; clarification is required.")

    matches: list[tuple[str, float]] = []
    for intent, score, patterns in _PATTERNS:
        if any(re.search(p, lower) for p in patterns):
            matches.append((intent, score))

    if not matches:
        return Classification("unknown", "read", 0.25, entities, decision="clarify",
                              reason="No supported intent matched the request.")

    # Multiple distinct action intents are ambiguous; do not choose one silently.
    distinct = list(dict.fromkeys(i for i, _ in matches))
    if len(distinct) > 1:
        alts = [{"intent": i, "confidence": s} for i, s in matches[:4]]
        return Classification("unknown", "read", 0.50, entities, decision="clarify",
                              alternatives=alts, reason="More than one supported intent matched.")

    intent, confidence = matches[0]
    spec = INTENT_CATALOGUE[intent]
    missing = [name for name in spec["required"] if name not in entities]
    # Missing required entity means the classifier can identify intent, but cannot route execution.
    if missing:
        decision = "clarify"
        reason = "Intent identified, but required synthetic record details are missing."
    elif confidence >= THRESHOLDS["execute"]:
        decision = "route"
        reason = "A single supported intent matched with sufficient confidence."
    else:
        decision = "clarify"
        reason = "Confidence is below the execution threshold."

    return Classification(
        intent=intent, action=spec["action"], confidence=confidence,
        entities=entities, needs_human_approval=spec["approval"],
        decision=decision, missing_entities=missing, reason=reason
    )
