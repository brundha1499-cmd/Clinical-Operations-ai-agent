# Synthetic operational dataset

Generated for the Clinical Operations Agent educational demonstration.

## Contents
- `clinical_operations_synthetic.db` — SQLite database with four normalized core tables.
- `patients.csv` — 180 synthetic patients.
- `appointments.csv` — 320 synthetic appointments.
- `insurance_authorizations.csv` — 500 synthetic approval requests.
- `tasks.csv` — 689 operational workflow tasks.

## Schema relationships
- `appointments.patient_id` → `patients.patient_id`
- `insurance_authorizations.patient_id` → `patients.patient_id`
- `insurance_authorizations.appointment_id` → `appointments.appointment_id` (nullable)
- `tasks.authorization_id` → `insurance_authorizations.authorization_id`
- `tasks.patient_id` → `patients.patient_id`

All patient names, contact details, records, insurers, references, statuses, and timestamps are fabricated. The dataset does not contain real patient information and is not suitable for clinical or insurance operations.
