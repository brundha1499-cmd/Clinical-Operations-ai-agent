PRAGMA foreign_keys=ON;
CREATE TABLE patients (
  patient_id TEXT PRIMARY KEY, synthetic_name TEXT NOT NULL, date_of_birth TEXT NOT NULL,
  phone TEXT NOT NULL, email TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE appointments (
  appointment_id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(patient_id),
  specialty TEXT NOT NULL, appointment_type TEXT NOT NULL, scheduled_at TEXT NOT NULL,
  status TEXT NOT NULL, location_code TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE insurance_authorizations (
  authorization_id TEXT PRIMARY KEY, patient_id TEXT NOT NULL REFERENCES patients(patient_id),
  appointment_id TEXT REFERENCES appointments(appointment_id), insurer TEXT NOT NULL,
  service TEXT NOT NULL, status TEXT NOT NULL, priority TEXT NOT NULL,
  submitted_at TEXT NOT NULL, sla_due_at TEXT NOT NULL, decision_at TEXT,
  required_documents TEXT NOT NULL, received_documents TEXT NOT NULL, missing_documents TEXT NOT NULL,
  external_reference TEXT NOT NULL UNIQUE, synthetic_only INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE tasks (
  task_id TEXT PRIMARY KEY, authorization_id TEXT NOT NULL REFERENCES insurance_authorizations(authorization_id),
  patient_id TEXT NOT NULL REFERENCES patients(patient_id), task_type TEXT NOT NULL, status TEXT NOT NULL,
  priority TEXT NOT NULL, assigned_role TEXT NOT NULL, due_at TEXT NOT NULL, created_at TEXT NOT NULL,
  completed_at TEXT, attempt_count INTEGER NOT NULL DEFAULT 0, last_error TEXT
);
