"""Single source of truth for model-callable tools.

Only names in this registry may be selected by the agent. The registry contains
function references and JSON-like schemas; no dynamic imports, getattr, SQL, or
arbitrary code execution are permitted.
"""
from __future__ import annotations
from datetime import date, datetime
from typing import Any

from calendar_service import TOOL_CATALOGUE, TOOL_FUNCTIONS

# Model-callable menu: exactly these five named calendar tools.
AGENT_TOOL_NAMES = (
    "calendar_find_available_slots",
    "calendar_get_appointment",
    "calendar_book_appointment",
    "calendar_reschedule_appointment",
    "calendar_cancel_appointment",
)

AGENT_TOOL_REGISTRY = {
    name: {
        **TOOL_CATALOGUE[name],
        "handler": TOOL_FUNCTIONS[name],
    }
    for name in AGENT_TOOL_NAMES
}

def public_tool_catalogue() -> list[dict[str, Any]]:
    """Return only model-safe metadata; never expose Python handlers."""
    return [
        {
            "name": name,
            "description": AGENT_TOOL_REGISTRY[name]["description"],
            "input_schema": AGENT_TOOL_REGISTRY[name]["input_schema"],
            "requires_approval": AGENT_TOOL_REGISTRY[name]["requires_approval"],
        }
        for name in AGENT_TOOL_NAMES
    ]

def validate_tool_call(tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Validate exact tool name, exact allowed keys, required fields and basic types."""
    if tool_name not in AGENT_TOOL_REGISTRY:
        raise KeyError("Tool is not in the approved agent tool menu.")
    if not isinstance(payload, dict):
        raise TypeError("Tool arguments must be a JSON object.")

    schema = AGENT_TOOL_REGISTRY[tool_name]["input_schema"]
    properties = schema.get("properties", {})
    required = schema.get("required", [])
    unknown = sorted(set(payload) - set(properties))
    if unknown:
        raise ValueError(f"Unsupported argument(s): {', '.join(unknown)}")
    missing = [key for key in required if key not in payload]
    if missing:
        raise ValueError(f"Missing required argument(s): {', '.join(missing)}")

    clean = dict(payload)
    for key, value in clean.items():
        spec = properties[key]
        expected = spec.get("type")
        if expected == "string" and (not isinstance(value, str) or not value.strip()):
            raise ValueError(f"{key} must be a non-empty string.")
        if expected == "integer":
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError(f"{key} must be an integer.")
            if "minimum" in spec and value < spec["minimum"]:
                raise ValueError(f"{key} is below the minimum.")
            if "maximum" in spec and value > spec["maximum"]:
                raise ValueError(f"{key} exceeds the maximum.")
        fmt = spec.get("format")
        if fmt == "date":
            try: date.fromisoformat(value)
            except (TypeError, ValueError): raise ValueError(f"{key} must use YYYY-MM-DD.")
        elif fmt == "date-time":
            try:
                parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
                if parsed.tzinfo is None: raise ValueError()
            except (TypeError, ValueError):
                raise ValueError(f"{key} must be an ISO date-time with timezone.")
    return clean

def get_handler(tool_name: str):
    """Resolve only from the fixed registry; callers must validate before invoking."""
    if tool_name not in AGENT_TOOL_REGISTRY:
        raise KeyError("Tool is not in the approved agent tool menu.")
    return AGENT_TOOL_REGISTRY[tool_name]["handler"]


def public_tool_catalogue_map() -> dict[str, dict[str, Any]]:
    """Compatibility representation keyed by tool name."""
    return {item["name"]: {k: v for k, v in item.items() if k != "name"}
            for item in public_tool_catalogue()}
