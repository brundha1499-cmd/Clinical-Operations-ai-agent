from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, Literal
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sqlite3, json, uuid, hashlib, os

DB = os.getenv("CLINICAL_AGENT_DB", "clinical_demo.db")
app = FastAPI(title="Clinical Operations Agent — Educational Demo", version="1.0.0")
BASE = Path(__file__).parent
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

ROLES = {"admin", "scheduler", "referral_coordinator", "authorization_specialist", "viewer"}
ROLE_ACTIONS = {
    "admin": {"*"},
    "scheduler": {"book_appointment", "reschedule_appointment", "search_slots", "send_reminder"},
    "referral_coordinator": {"check_referral", "request_documents"},
    "authorization_specialist": {"check_authorization", "escalate_authorization", "request_documents"},
    "viewer": {"read"},
}

def now():
    return datetime.now(timezone.utc)

def connect():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = connect()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS patients(id TEXT PRIMARY KEY, name TEXT, dob TEXT, phone TEXT);
    CREATE TABLE IF NOT EXISTS appointments(id TEXT PRIMARY KEY, patient_id TEXT, specialty TEXT, appt_type TEXT, starts_at TEXT, status TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS referrals(id TEXT PRIMARY KEY, patient_id TEXT, specialty TEXT, status TEXT, required_docs TEXT, received_docs TEXT);
    CREATE TABLE IF NOT EXISTS authorizations(id TEXT PRIMARY KEY, patient_id TEXT, insurer TEXT, service TEXT, status TEXT, sla_due TEXT, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS requests(id TEXT PRIMARY KEY, raw_text TEXT, intent TEXT, entities TEXT, status TEXT, workflow_id TEXT, role TEXT, created_at TEXT, result TEXT);
    CREATE TABLE IF NOT EXISTS workflows(id TEXT PRIMARY KEY, request_id TEXT, action TEXT, status TEXT, attempts INTEGER, idempotency_key TEXT UNIQUE, error TEXT, created_at TEXT, updated_at TEXT);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, role TEXT, action TEXT, entity_type TEXT, entity_id TEXT, outcome TEXT, details TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY, kind TEXT, payload TEXT, status TEXT, attempts INTEGER, last_error TEXT, created_at TEXT);
    CREATE TABLE IF NOT EXISTS approvals(id TEXT PRIMARY KEY, workflow_id TEXT, action TEXT, requested_by TEXT, status TEXT, reason TEXT, created_at TEXT, decided_at TEXT);
    """)
    if c.execute("SELECT COUNT(*) FROM patients").fetchone()[0] == 0:
        c.executemany("INSERT INTO patients VALUES(?,?,?,?)", [
            ("PT-1001","Avery Morgan","1988-04-12","+1-555-0101"),
            ("PT-1002","Jordan Lee","1975-09-23","+1-555-0102"),
            ("PT-1003","Taylor Singh","1992-01-08","+1-555-0103"),
        ])
        c.executemany("INSERT INTO referrals VALUES(?,?,?,?,?,?)", [
            ("RF-2001","PT-1001","Cardiology","pending",json.dumps(["clinical_notes","ecg_report"]),json.dumps(["clinical_notes"])),
            ("RF-2002","PT-1002","Dermatology","complete",json.dumps(["referral_letter"]),json.dumps(["referral_letter"])),
        ])
        c.executemany("INSERT INTO authorizations VALUES(?,?,?,?,?,?,?)", [
            ("PA-3001","PT-1001","Northstar Health","Cardiology consultation","pending",(now()+timedelta(hours=7)).isoformat(),now().isoformat()),
            ("PA-3002","PT-1002","Evergreen Mutual","MRI knee","in_review",(now()-timedelta(hours=3)).isoformat(),now().isoformat()),
            ("PA-3003","PT-1003","Northstar Health","Dermatology visit","approved",(now()+timedelta(days=2)).isoformat(),now().isoformat()),
        ])
        c.executemany("INSERT INTO appointments VALUES(?,?,?,?,?,?,?)", [
            ("AP-4001","PT-1002","Dermatology","follow-up",(now()+timedelta(days=1)).replace(hour=10,minute=0,second=0,microsecond=0).isoformat(),"booked",now().isoformat()),
            ("AP-4002","PT-1003","Primary Care","consultation",(now()+timedelta(days=2)).replace(hour=14,minute=0,second=0,microsecond=0).isoformat(),"booked",now().isoformat()),
        ])
    c.commit(); c.close()

init_db()

# Mock calendar tool integration. The model can only select from this named allow-list.
from calendar_service import TOOL_CATALOGUE, TOOL_FUNCTIONS
from agent_tool_registry import AGENT_TOOL_REGISTRY, public_tool_catalogue, public_tool_catalogue_map, validate_tool_call, get_handler

def audit(actor, role, action, etype, eid, outcome, details=""):
    c=connect()
    c.execute("INSERT INTO audit(actor,role,action,entity_type,entity_id,outcome,details,created_at) VALUES(?,?,?,?,?,?,?,?)",
              (actor,role,action,etype,eid,outcome,details,now().isoformat()))
    c.commit(); c.close()

def require_role(role: str, action: str):
    if role not in ROLES: raise HTTPException(401, "Unknown demo role")
    allowed=ROLE_ACTIONS[role]
    if "*" not in allowed and action not in allowed and "read" not in allowed:
        raise HTTPException(403, f"Role '{role}' cannot perform '{action}'")

class RequestIn(BaseModel):
    text: str = Field(min_length=3, max_length=2000)
    role: Literal["admin","scheduler","referral_coordinator","authorization_specialist","viewer"] = "scheduler"
    actor: str = "demo-user"

class DecisionIn(BaseModel):
    decision: Literal["approve","reject"]
    actor: str = "demo-admin"
    role: Literal["admin"] = "admin"

class IntentResult(BaseModel):
    intent: str
    entities: dict
    action: str
    confidence: float
    needs_human_approval: bool = False


from intent_classifier import classify_intent, INTENT_CATALOGUE

def understand(text: str) -> IntentResult:
    """Compatibility adapter: classification only; workflow execution remains deterministic."""
    classified = classify_intent(text)
    # Only actions implemented by the workflow runner may enter that runner.
    # Calendar-only intents are classified in preview but must use the dedicated
    # /api/calendar/tools allow-list rather than falling through to a generic workflow.
    workflow_actions = {
        "book_appointment", "reschedule_appointment", "check_referral",
        "request_documents", "check_authorization", "escalate_authorization"
    }
    action = classified.action if (
        classified.decision == "route" and classified.action in workflow_actions
    ) else "read"
    return IntentResult(
        intent=classified.intent,
        entities=classified.entities,
        action=action,
        confidence=classified.confidence,
        needs_human_approval=classified.needs_human_approval,
    )

def workflow_row(request_id, action, idem):
    wid="WF-"+uuid.uuid4().hex[:10].upper()
    c=connect()
    c.execute("INSERT INTO workflows VALUES(?,?,?,?,?,?,?,?,?)",(wid,request_id,action,"queued",0,idem,None,now().isoformat(),now().isoformat()))
    c.commit(); c.close()
    return wid

def run_workflow(wid, request_id, parsed, role, actor):
    c=connect()
    wf=c.execute("SELECT * FROM workflows WHERE id=?",(wid,)).fetchone()
    if not wf: raise HTTPException(404,"Workflow not found")
    action=wf["action"]; ent=parsed.entities
    try:
        require_role(role,action)
        c.execute("UPDATE workflows SET status='running',attempts=attempts+1,updated_at=? WHERE id=?",(now().isoformat(),wid))
        result={}
        if action=="book_appointment":
            pid=ent.get("patient_id")
            if not pid or not c.execute("SELECT 1 FROM patients WHERE id=?",(pid,)).fetchone():
                raise ValueError("A valid synthetic patient_id is required")
            if parsed.needs_human_approval:
                aid="APR-"+uuid.uuid4().hex[:8].upper()
                c.execute("INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)",(aid,wid,action,actor,"waiting","Booking changes require staff approval",now().isoformat(),None))
                result={"approval_id":aid,"message":"Awaiting human approval; no booking created."}
                status="waiting_approval"
            else: status="completed"
        elif action=="reschedule_appointment":
            apid=ent.get("appointment_id")
            if not apid: raise ValueError("appointment_id is required")
            result={"appointment_id":apid,"message":"Reschedule proposal staged for staff approval."}
            aid="APR-"+uuid.uuid4().hex[:8].upper()
            c.execute("INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)",(aid,wid,action,actor,"waiting","Rescheduling requires staff approval",now().isoformat(),None))
            result["approval_id"]=aid; status="waiting_approval"
        elif action=="check_referral":
            rid=ent.get("referral_id")
            row=c.execute("SELECT * FROM referrals WHERE id=?",(rid,)).fetchone() if rid else None
            if not row: raise ValueError("Known referral_id (RF-...) is required")
            required=json.loads(row["required_docs"]); received=json.loads(row["received_docs"])
            result={"referral_id":rid,"status":row["status"],"missing_documents":[d for d in required if d not in received]}
            status="completed"
        elif action=="request_documents":
            rid=ent.get("referral_id")
            row=c.execute("SELECT * FROM referrals WHERE id=?",(rid,)).fetchone() if rid else None
            if not row: raise ValueError("Known referral_id (RF-...) is required")
            required=json.loads(row["required_docs"]); received=json.loads(row["received_docs"])
            missing=[d for d in required if d not in received]
            oid="MSG-"+uuid.uuid4().hex[:8].upper()
            c.execute("INSERT INTO outbox VALUES(?,?,?,?,?,?,?)",(oid,"document_request",json.dumps({"referral_id":rid,"missing":missing}),"queued",0,None,now().isoformat()))
            aid="APR-"+uuid.uuid4().hex[:8].upper()
            c.execute("INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)",(aid,wid,action,actor,"waiting","Outbound document request requires staff approval",now().isoformat(),None))
            result={"referral_id":rid,"missing_documents":missing,"approval_id":aid,"message":"Draft queued; not sent until approved."}
            status="waiting_approval"
        elif action=="check_authorization":
            aid=ent.get("authorization_id")
            row=c.execute("SELECT * FROM authorizations WHERE id=?",(aid,)).fetchone() if aid else None
            if not row: raise ValueError("Known authorization_id (PA-...) is required")
            result={"authorization_id":aid,"status":row["status"],"insurer":row["insurer"],"sla_due":row["sla_due"]}
            status="completed"
        elif action=="escalate_authorization":
            rows=c.execute("SELECT * FROM authorizations WHERE status IN ('pending','in_review') AND sla_due<=?",(now().isoformat(),)).fetchall()
            result={"breaches":[dict(r) for r in rows],"message":"Escalations are staged for staff review."}
            aid="APR-"+uuid.uuid4().hex[:8].upper()
            c.execute("INSERT INTO approvals VALUES(?,?,?,?,?,?,?,?)",(aid,wid,action,actor,"waiting","SLA escalation requires staff confirmation",now().isoformat(),None))
            result["approval_id"]=aid; status="waiting_approval"
        else:
            result={"message":"Request classified but no executable workflow selected."}; status="needs_clarification"
        c.execute("UPDATE workflows SET status=?,updated_at=? WHERE id=?",(status,now().isoformat(),wid))
        c.execute("UPDATE requests SET status=?,result=? WHERE id=?",(status,json.dumps(result),request_id))
        c.commit()
        audit(actor,role,action,"workflow",wid,status,json.dumps(result))
        return {"workflow_id":wid,"status":status,"result":result}
    except Exception as e:
        c.execute("UPDATE workflows SET status='failed',error=?,updated_at=? WHERE id=?",(str(e),now().isoformat(),wid))
        c.execute("UPDATE requests SET status='failed',result=? WHERE id=?",(json.dumps({"error":str(e)}),request_id))
        oid="ERR-"+uuid.uuid4().hex[:8].upper()
        c.execute("INSERT INTO outbox VALUES(?,?,?,?,?,?,?)",(oid,"dead_letter",json.dumps({"workflow_id":wid,"error":str(e)}),"dead_letter",1,str(e),now().isoformat()))
        c.commit()
        audit(actor,role,action,"workflow",wid,"failed",str(e))
        return {"workflow_id":wid,"status":"failed","result":{"error":str(e)}}
    finally:
        c.close()

@app.get("/")
def home(): return FileResponse(BASE/"static"/"index.html")

@app.get("/api/health")
def health(): return {"status":"ok","label":"Synthetic educational demo only"}


@app.post("/api/intents/classify")
def classify_request(body: RequestIn):
    """Preview intent classification without creating a workflow or changing state."""
    return classify_intent(body.text).to_dict()

@app.post("/api/requests")
def create_request(body: RequestIn, idempotency_key: Optional[str]=Header(default=None)):
    parsed=understand(body.text)
    key=idempotency_key or hashlib.sha256((body.actor+body.text).encode()).hexdigest()
    c=connect()
    existing=c.execute("SELECT * FROM workflows WHERE idempotency_key=?",(key,)).fetchone()
    if existing:
        req=c.execute("SELECT * FROM requests WHERE id=?",(existing["request_id"],)).fetchone()
        c.close()
        return {"request_id":req["id"],"workflow_id":existing["id"],"status":existing["status"],"result":json.loads(req["result"] or "{}"),"idempotent_replay":True}
    rid="RQ-"+uuid.uuid4().hex[:10].upper()
    c.execute("INSERT INTO requests VALUES(?,?,?,?,?,?,?,?,?)",(rid,body.text,parsed.intent,json.dumps(parsed.entities),"queued",None,body.role,now().isoformat(),None))
    c.commit(); c.close()
    wid=workflow_row(rid,parsed.action,key)
    c=connect(); c.execute("UPDATE requests SET workflow_id=? WHERE id=?",(wid,rid)); c.commit(); c.close()
    if parsed.action=="read":
        audit(body.actor,body.role,"classify","request",rid,"needs_clarification",body.text)
        return {"request_id":rid,"workflow_id":wid,"intent":parsed.intent,"entities":parsed.entities,"status":"needs_clarification","result":{"message":"Please specify a supported action and synthetic record ID."}}
    out=run_workflow(wid,rid,parsed,body.role,body.actor)
    return {"request_id":rid,"intent":parsed.intent,"entities":parsed.entities,**out}

@app.post("/api/approvals/{approval_id}/decision")
def decide(approval_id: str, body: DecisionIn):
    c=connect(); row=c.execute("SELECT * FROM approvals WHERE id=?",(approval_id,)).fetchone()
    if not row: c.close(); raise HTTPException(404,"Approval not found")
    if row["status"]!="waiting": c.close(); raise HTTPException(409,"Approval already decided")
    c.execute("UPDATE approvals SET status=?,decided_at=? WHERE id=?",(body.decision,now().isoformat(),approval_id))
    wf=row["workflow_id"]
    # Approved external actions are represented as synthetic state transitions only.
    if body.decision=="approve" and row["action"]=="book_appointment":
        req=c.execute("SELECT * FROM requests WHERE workflow_id=?",(wf,)).fetchone()
        ent=json.loads(req["entities"])
        pid=ent["patient_id"]
        apid="AP-"+uuid.uuid4().hex[:8].upper()
        start=(now()+timedelta(days=3)).replace(hour=9,minute=0,second=0,microsecond=0).isoformat()
        c.execute("INSERT INTO appointments VALUES(?,?,?,?,?,?,?)",(apid,pid,ent.get("specialty","Primary Care"),"consultation",start,"booked",now().isoformat()))
        result={"appointment_id":apid,"starts_at":start,"status":"booked"}
        c.execute("UPDATE requests SET status='completed',result=? WHERE workflow_id=?",(json.dumps(result),wf))
        c.execute("UPDATE workflows SET status='completed',updated_at=? WHERE id=?",(now().isoformat(),wf))
    elif body.decision=="approve" and row["action"]=="request_documents":
        c.execute("UPDATE outbox SET status='sent' WHERE kind='document_request' AND status='queued' AND payload LIKE '%' || (SELECT json_extract(entities,'$.referral_id') FROM requests WHERE workflow_id=?) || '%'",(wf,))
        result={"message":"Synthetic document request marked sent."}
        c.execute("UPDATE requests SET status='completed',result=? WHERE workflow_id=?",(json.dumps(result),wf))
        c.execute("UPDATE workflows SET status='completed',updated_at=? WHERE id=?",(now().isoformat(),wf))
    else:
        result={"message":"Approval decision recorded; no external action executed."}
        c.execute("UPDATE requests SET status=?,result=? WHERE workflow_id=?",("completed" if body.decision=="approve" else "rejected",json.dumps(result),wf))
        c.execute("UPDATE workflows SET status=?,updated_at=? WHERE id=?",("completed" if body.decision=="approve" else "rejected",now().isoformat(),wf))
    c.commit(); c.close()
    audit(body.actor,body.role,"approval_"+body.decision,"approval",approval_id,"recorded")
    return {"approval_id":approval_id,"decision":body.decision,"result":result}

@app.get("/api/dashboard")
def dashboard():
    c=connect()
    def rows(q,args=()): return [dict(r) for r in c.execute(q,args).fetchall()]
    data={
      "requests":rows("SELECT * FROM requests ORDER BY created_at DESC LIMIT 25"),
      "workflows":rows("SELECT * FROM workflows ORDER BY created_at DESC LIMIT 25"),
      "approvals":rows("SELECT * FROM approvals WHERE status='waiting' ORDER BY created_at"),
      "appointments":rows("SELECT * FROM appointments WHERE status='booked' ORDER BY starts_at"),
      "authorizations":rows("SELECT * FROM authorizations ORDER BY sla_due"),
      "failures":rows("SELECT * FROM workflows WHERE status='failed' ORDER BY updated_at DESC"),
      "escalations":rows("SELECT * FROM approvals WHERE action='escalate_authorization' ORDER BY created_at DESC"),
      "outbox":rows("SELECT * FROM outbox ORDER BY created_at DESC LIMIT 20"),
      "audit":rows("SELECT * FROM audit ORDER BY created_at DESC LIMIT 30"),
      "counts":{}
    }
    data["counts"]={
      "active_requests":c.execute("SELECT COUNT(*) FROM requests WHERE status IN ('queued','running','waiting_approval')").fetchone()[0],
      "waiting_approvals":c.execute("SELECT COUNT(*) FROM approvals WHERE status='waiting'").fetchone()[0],
      "sla_breaches":c.execute("SELECT COUNT(*) FROM authorizations WHERE status IN ('pending','in_review') AND sla_due<=?",(now().isoformat(),)).fetchone()[0],
      "upcoming_appointments":c.execute("SELECT COUNT(*) FROM appointments WHERE status='booked' AND starts_at>=?",(now().isoformat(),)).fetchone()[0],
      "failures":c.execute("SELECT COUNT(*) FROM workflows WHERE status='failed'").fetchone()[0]
    }
    c.close(); return data

@app.get("/api/catalogue")
def catalogue():
    return {"approved_actions":[
      {"action":"book_appointment","description":"Stage a synthetic appointment booking; staff approval required"},
      {"action":"reschedule_appointment","description":"Stage a synthetic appointment change; staff approval required"},
      {"action":"check_referral","description":"Read referral status and missing-document list"},
      {"action":"request_documents","description":"Queue synthetic document request; staff approval required"},
      {"action":"check_authorization","description":"Read synthetic authorization status"},
      {"action":"escalate_authorization","description":"Identify SLA breaches and stage escalation for approval"}
    ],"roles":ROLES}

@app.post("/api/demo/reset")
def reset():
    global DB
    if os.getenv("ALLOW_DEMO_RESET","true").lower()!="true": raise HTTPException(403,"Reset disabled")
    c=connect()
    for table in ["patients","appointments","referrals","authorizations","requests","workflows","audit","outbox","approvals"]:
        c.execute(f"DELETE FROM {table}")
    c.commit(); c.close(); init_db()
    return {"status":"reset","message":"Synthetic demo data restored."}


@app.get("/api/agent/tools")
def agent_tool_catalogue():
    """The exact, fixed menu exposed to the reasoning agent."""
    return {"tools": public_tool_catalogue(), "count": len(public_tool_catalogue())}

@app.get("/api/calendar/tools")
def calendar_tools():
    # Backward-compatible keyed representation for existing clients.
    return {"tools": public_tool_catalogue_map()}

@app.post("/api/agent/tools/{tool_name}")
def invoke_agent_tool(tool_name: str, payload: dict, idempotency_key: Optional[str]=Header(default=None)):
    """Strict dispatcher: exact allow-list, exact argument schema, then fixed handler."""
    try:
        args = validate_tool_call(tool_name, payload)
        handler = get_handler(tool_name)
    except KeyError:
        raise HTTPException(404, "Tool is not in the approved agent tool menu.")
    except (TypeError, ValueError) as e:
        raise HTTPException(422, str(e))

    if tool_name in {"calendar_book_appointment","calendar_reschedule_appointment","calendar_cancel_appointment"}:
        args["idempotency_key"] = idempotency_key
    try:
        result = handler(**args)
        audit("agent-tool-dispatcher","admin",tool_name,"calendar",
              str(result.get("appointment_id","search")), "success", json.dumps(result))
        return {"tool":tool_name,"status":"success","result":result}
    except ValueError as e:
        audit("agent-tool-dispatcher","admin",tool_name,"calendar","unknown","rejected",str(e))
        raise HTTPException(409, str(e))
    except TypeError as e:
        raise HTTPException(422, str(e))

# Backward-compatible route delegates to the same strict dispatcher.
@app.post("/api/calendar/tools/{tool_name}")
def invoke_calendar_tool(tool_name: str, payload: dict, idempotency_key: Optional[str]=Header(default=None)):
    return invoke_agent_tool(tool_name, payload, idempotency_key)
