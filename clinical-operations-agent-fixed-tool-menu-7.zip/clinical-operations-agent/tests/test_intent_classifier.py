from intent_classifier import classify_intent

def test_referral_status_routes_with_required_id():
    result = classify_intent("Check referral status for RF-2001")
    assert result.intent == "check_referral"
    assert result.decision == "route"
    assert result.entities["referral_id"] == "RF-2001"

def test_missing_id_requires_clarification():
    result = classify_intent("Check referral status")
    assert result.intent == "check_referral"
    assert result.decision == "clarify"
    assert result.missing_entities == ["referral_id"]

def test_booking_is_approval_gated():
    result = classify_intent("Book appointment for PT-1001 in Cardiology")
    assert result.intent == "book_appointment"
    assert result.decision == "route"
    assert result.needs_human_approval is True

def test_conflicting_intents_clarify():
    result = classify_intent("Book an appointment for PT-1001 and check referral RF-2001")
    assert result.decision == "clarify"
    assert result.intent == "unknown"
    assert len(result.alternatives) >= 2

def test_negated_action_does_not_route():
    result = classify_intent("Do not cancel appointment AP-4001")
    assert result.decision == "clarify"
    assert result.action == "read"

def test_search_slots_needs_specialty():
    result = classify_intent("Find available appointment slots")
    assert result.intent == "search_slots"
    assert result.decision == "clarify"
    assert "specialty" in result.missing_entities
