from fastapi.testclient import TestClient
import sqlite3
import app
import calendar_service

client = TestClient(app.app)

def test_calendar_catalogue_is_small_and_named():
    r = client.get("/api/calendar/tools")
    assert r.status_code == 200
    names = set(r.json()["tools"].keys())
    assert names == {
        "calendar_find_available_slots",
        "calendar_get_appointment",
        "calendar_book_appointment",
        "calendar_reschedule_appointment",
        "calendar_cancel_appointment",
    }

def test_unknown_calendar_tool_is_rejected():
    r = client.post("/api/calendar/tools/run_sql", json={"query":"DELETE FROM patients"})
    assert r.status_code == 404

def test_booking_requires_approval():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.execute("CREATE TABLE approvals (id TEXT PRIMARY KEY, status TEXT)")
    try:
        try:
            calendar_service._approved(conn, "NOT-A-REAL-APPROVAL")
            assert False, "Expected missing approval to be rejected"
        except ValueError as exc:
            assert "staff approval" in str(exc)
    finally:
        conn.close()
