from fastapi.testclient import TestClient
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import app

client=TestClient(app.app)

def test_health():
    r=client.get("/api/health")
    assert r.status_code==200
    assert r.json()["status"]=="ok"

def test_referral_lookup():
    r=client.post("/api/requests",json={"text":"Check referral status for RF-2001","role":"referral_coordinator"})
    assert r.status_code==200
    assert r.json()["status"]=="completed"
    assert "ecg_report" in r.json()["result"]["missing_documents"]

def test_booking_requires_approval():
    r=client.post("/api/requests",json={"text":"Book appointment for PT-1001 in Cardiology","role":"scheduler"})
    assert r.status_code==200
    assert r.json()["status"]=="waiting_approval"
    assert "approval_id" in r.json()["result"]
