import pytest
from agent_tool_registry import (
    AGENT_TOOL_NAMES, public_tool_catalogue, validate_tool_call, get_handler
)

def test_registry_is_exact_fixed_menu():
    assert AGENT_TOOL_NAMES == (
        "calendar_find_available_slots",
        "calendar_get_appointment",
        "calendar_book_appointment",
        "calendar_reschedule_appointment",
        "calendar_cancel_appointment",
    )
    assert len(public_tool_catalogue()) == 5

def test_unknown_tool_is_rejected():
    with pytest.raises(KeyError):
        get_handler("run_sql")

def test_extra_arguments_are_rejected():
    with pytest.raises(ValueError, match="Unsupported argument"):
        validate_tool_call("calendar_get_appointment", {
            "appointment_id": "AP-4001", "sql": "DROP TABLE appointments"
        })

def test_missing_required_arguments_are_rejected():
    with pytest.raises(ValueError, match="Missing required"):
        validate_tool_call("calendar_get_appointment", {})

def test_timezone_required_for_booking_datetime():
    with pytest.raises(ValueError, match="timezone"):
        validate_tool_call("calendar_book_appointment", {
            "patient_id": "PT-1001", "specialty": "Cardiology",
            "starts_at": "2026-12-01T09:00:00", "approval_id": "APR-1234"
        })

def test_valid_read_tool_resolves_to_registered_handler():
    args = validate_tool_call("calendar_get_appointment", {"appointment_id":"AP-4001"})
    assert callable(get_handler("calendar_get_appointment"))
    assert args == {"appointment_id":"AP-4001"}
