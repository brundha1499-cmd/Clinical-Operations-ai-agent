# Clinical Operations Agent — Educational Demonstration

A local, full-stack prototype for outpatient scheduling, referral coordination, and synthetic insurance-authorization workflow management.

**This is not a clinical product.** It is an educational healthcare operations automation demonstration. It must not be used for real patient care, real patient information, clinical decisions, or real insurance processing. All seeded records are fictional.

## Architecture

- **UI:** responsive HTML/CSS/JavaScript operations dashboard.
- **API:** FastAPI REST service (`app.py`).
- **Storage:** SQLite; initialized with synthetic patients, appointments, referrals, and authorizations.
- **Workflow runner:** deterministic Python workflow catalogue. Model output never directly executes SQL or external actions.
- **Intent layer:** `intent_classifier.py` provides a deterministic, allow-listed classifier with entity extraction, confidence thresholds, ambiguity handling, required-entity checks, and negation safeguards. It only classifies; it never executes actions. The requested GPT-6/Astra reasoning layer remains an integration seam; no model API is connected.
- **Controls:** role checks, idempotency keys, workflow states, audit log, outbox/dead-letter records, retry counter field, and human approval gates for sensitive actions.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```

Open http://127.0.0.1:8000. API docs: http://127.0.0.1:8000/docs.

## Synthetic demo identities

- Patients: `PT-1001`, `PT-1002`, `PT-1003`
- Referrals: `RF-2001`, `RF-2002`
- Authorizations: `PA-3001`, `PA-3002`, `PA-3003`
- Appointments: `AP-4001`, `AP-4002`

## Try these requests

- `Check referral status for RF-2001` (referral coordinator)
- `Check authorization status for PA-3001` (authorization specialist)
- `Are documents missing for RF-2001?` (referral coordinator; creates an approval-gated outbox draft)
- `Book appointment for PT-1001 in Cardiology` (scheduler; requires admin approval)
- `Show approvals approaching SLA deadline` (authorization specialist; stages escalation for approval)

Use the dashboard's approval controls to approve/reject waiting actions. Approvals are synthetic and local.

## API surface

- `GET /api/health`
- `GET /api/dashboard`
- `GET /api/catalogue`
- `POST /api/intents/classify` — preview a classification without creating a workflow or changing state.
- `POST /api/requests` — accepts `text`, `role`, `actor`; supports `Idempotency-Key`.
- `POST /api/approvals/{approval_id}/decision` — admin-only approval/rejection.
- `POST /api/demo/reset` — restores synthetic seed data.

## Production-hardening checklist (not implemented / not certified)

1. Replace the deterministic parser with a secured model adapter. Require schema-constrained output, confidence thresholds, prompt-injection resistance, and strict allow-list mapping from model intent to the approved action catalogue.
2. Move from SQLite to managed Postgres; add migrations, encryption at rest/in transit, secret management, backups, tenant isolation, and retention controls.
3. Enforce authentication/authorization with an identity provider, scoped permissions, MFA, and server-side role claims. Demo role values are not authentication.
4. Implement real retry scheduling with exponential backoff, bounded attempts, worker leases, dead-letter replay tooling, and transactional outbox delivery.
5. Add appointment slot inventory, conflict detection, timezone-aware availability, cancellation/compensation workflows, and concurrency tests.
6. Add immutable audit retention, correlation IDs, metrics, tracing, alerting, and operational runbooks.
7. Complete privacy, security, accessibility, legal, clinical safety, and regulatory review before any real-world use.

## Safety and action semantics

- Model/intent layer proposes an action only.
- Backend validates the action and role against a fixed catalogue.
- Booking, rescheduling, outbound document requests, and SLA escalations require human approval.
- The messaging outbox is simulated; no email/SMS is sent.
- The demo has no connection to EHR, payer, calendar, or messaging providers.
- Reset is enabled for local demos by default. Set `ALLOW_DEMO_RESET=false` to disable it.


## Synthetic operational dataset

A separate normalized SQLite dataset is included in `data/clinical_operations_synthetic.db` with 180 synthetic patients, 320 appointments, 500 insurance authorization requests, and operational tasks. CSV exports for each core table are in `data/`. See `data/README.md` for schema relationships and safety notes.


## Mock calendar service

**Core architectural principle: the AI may interpret requests and choose an approved tool, but it must never directly manipulate operational systems or databases.** Every state change goes through a small, named, deterministic, validated tool catalogue.

Calendar tools:
- `calendar_find_available_slots` — read-only availability search.
- `calendar_get_appointment` — read-only appointment lookup.
- `calendar_book_appointment` — booking, requires recorded staff approval.
- `calendar_reschedule_appointment` — reschedule, requires recorded staff approval.
- `calendar_cancel_appointment` — cancellation, requires recorded staff approval.

Endpoints:
- `GET /api/calendar/tools` — discover tool names and JSON input schemas.
- `POST /api/calendar/tools/{tool_name}` — invoke one allow-listed tool with a JSON payload.
- Mutating tools require an `approval_id` whose status is `approve`.
- Mutating calls support the `Idempotency-Key` header; duplicate requests replay the prior result.
- Slot search is deterministic and uses weekday hourly slots in UTC, checking the local mock appointment table.

The calendar is simulated and does not connect to external scheduling systems.


## Intent classifier

The classifier is in `intent_classifier.py` and recognizes a small allow-list:
`book_appointment`, `reschedule_appointment`, `cancel_appointment`,
`search_slots`, `check_referral`, `request_documents`,
`check_authorization`, `sla_watch`, and `get_appointment`.

Safety behavior:
- Confidence threshold for routing: 0.80.
- Missing required entities (for example, a referral ID) force clarification.
- Requests matching multiple intents are marked ambiguous and are not routed.
- Negated action requests are not routed.
- Mutating intents are marked as requiring human approval.
- The classifier has no database access and cannot invoke calendar tools.
- `/api/intents/classify` is a read-only preview endpoint.

Example:
```bash
curl -X POST http://127.0.0.1:8000/api/intents/classify \
  -H "Content-Type: application/json" \
  -d '{"text":"Check referral status for RF-2001"}'
```

**Architecture rule:** AI/classifier output is a proposal. The server validates and routes only supported actions; deterministic tools execute. Human approval remains mandatory for sensitive changes.


## Fixed agent tool menu (production guardrail)

The model-callable menu is defined in `agent_tool_registry.py`. It contains exactly
five named tools:

1. `calendar_find_available_slots` — read-only
2. `calendar_get_appointment` — read-only
3. `calendar_book_appointment` — staff approval required
4. `calendar_reschedule_appointment` — staff approval required
5. `calendar_cancel_appointment` — staff approval required

The agent cannot invent a tool name, call arbitrary Python functions, run SQL,
or pass extra arguments. `POST /api/agent/tools/{tool_name}` dispatches only
through the fixed registry and validates required fields, allowed fields, basic
types, date formats, and timezone-aware datetimes. The old
`/api/calendar/tools/{tool_name}` endpoint remains as a compatibility alias
and uses the same dispatcher. `GET /api/agent/tools` returns the exact menu.

The classifier may recommend an intent, but it does not grant tool permissions.
The backend remains the enforcement point; mutation tools verify recorded staff
approval before changing calendar state. In a production deployment, also enforce
authentication, per-tool RBAC, tenant scoping, rate limits, and approval identity
at the API gateway/service layer.
