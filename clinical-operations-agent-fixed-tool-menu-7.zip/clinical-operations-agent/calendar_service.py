"""Narrow, deterministic mock calendar tools for the educational demo.

Architectural boundary: the language model may select and parameterize an approved
tool, but it never reads/writes the calendar database directly. These functions
validate inputs and own all calendar state transitions.
"""
from datetime import datetime, timedelta, timezone, date
from typing import Optional
import sqlite3, os, uuid

DB = os.getenv("CLINICAL_AGENT_DB", "clinical_demo.db")

TOOL_CATALOGUE = {
    "calendar_find_available_slots": {
        "description": "Find open mock appointment slots for a specialty and date range.",
        "input_schema": {
            "type": "object",
            "required": ["specialty", "date_from", "date_to"],
            "properties": {
                "specialty": {"type": "string"},
                "date_from": {"type": "string", "format": "date"},
                "date_to": {"type": "string", "format": "date"},
                "appointment_type": {"type": "string"},
                "limit": {"type": "integer", "minimum": 1, "maximum": 50}
            }
        },
        "requires_approval": False
    },
    "calendar_get_appointment": {
        "description": "Retrieve one appointment by its synthetic appointment ID.",
        "input_schema": {
            "type": "object", "required": ["appointment_id"],
            "properties": {"appointment_id": {"type": "string"}}
        },
        "requires_approval": False
    },
    "calendar_book_appointment": {
        "description": "Create a booking in the mock calendar after staff approval.",
        "input_schema": {
            "type": "object", "required": ["patient_id", "specialty", "starts_at", "approval_id"],
            "properties": {
                "patient_id": {"type": "string"}, "specialty": {"type": "string"},
                "starts_at": {"type": "string", "format": "date-time"},
                "appointment_type": {"type": "string"}, "approval_id": {"type": "string"}
            }
        },
        "requires_approval": True
    },
    "calendar_reschedule_appointment": {
        "description": "Move an existing booking to an available time after staff approval.",
        "input_schema": {
            "type": "object", "required": ["appointment_id", "new_starts_at", "approval_id"],
            "properties": {
                "appointment_id": {"type": "string"}, "new_starts_at": {"type": "string", "format": "date-time"},
                "approval_id": {"type": "string"}
            }
        },
        "requires_approval": True
    },
    "calendar_cancel_appointment": {
        "description": "Cancel a mock booking after staff approval.",
        "input_schema": {
            "type": "object", "required": ["appointment_id", "approval_id"],
            "properties": {"appointment_id": {"type": "string"}, "approval_id": {"type": "string"}}
        },
        "requires_approval": True
    }
}

def _db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    c.execute("""CREATE TABLE IF NOT EXISTS calendar_tool_idempotency (
        idempotency_key TEXT PRIMARY KEY, tool_name TEXT NOT NULL,
        response_json TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    c.commit()
    return c

def _approved(c, approval_id):
    row = c.execute("SELECT status FROM approvals WHERE id=?", (approval_id,)).fetchone()
    if not row or row["status"] != "approve":
        raise ValueError("A recorded staff approval is required before this calendar action.")

def _parse_dt(value):
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError("Datetime must include a timezone offset.")
    return dt.astimezone(timezone.utc)

def _slot_is_free(c, starts_at, exclude_id=None):
    q = "SELECT id FROM appointments WHERE starts_at=? AND status='booked'"
    args = [starts_at]
    if exclude_id:
        q += " AND id<>?"
        args.append(exclude_id)
    return c.execute(q, args).fetchone() is None

def calendar_find_available_slots(specialty, date_from, date_to, appointment_type="consultation", limit=20):
    start = date.fromisoformat(date_from)
    end = date.fromisoformat(date_to)
    if end < start or (end - start).days > 90:
        raise ValueError("Use a valid date range of 0–90 days.")
    if not 1 <= int(limit) <= 50:
        raise ValueError("limit must be between 1 and 50.")
    c = _db()
    slots = []
    day = start
    while day <= end and len(slots) < int(limit):
        if day.weekday() < 5:
            for hour in [9, 10, 11, 13, 14, 15, 16]:
                dt = datetime(day.year, day.month, day.day, hour, 0, tzinfo=timezone.utc)
                iso = dt.isoformat()
                if dt > datetime.now(timezone.utc) and _slot_is_free(c, iso):
                    slots.append({"starts_at": iso, "specialty": specialty, "appointment_type": appointment_type})
                    if len(slots) >= int(limit):
                        break
        day += timedelta(days=1)
    c.close()
    return {"slots": slots, "count": len(slots), "timezone": "UTC", "source": "mock_calendar"}

def calendar_get_appointment(appointment_id):
    c = _db()
    row = c.execute("SELECT * FROM appointments WHERE id=?", (appointment_id,)).fetchone()
    c.close()
    if not row:
        raise ValueError("Appointment not found.")
    return dict(row)

def calendar_book_appointment(patient_id, specialty, starts_at, approval_id, appointment_type="consultation", idempotency_key=None):
    dt = _parse_dt(starts_at)
    iso = dt.isoformat()
    key = idempotency_key or f"book:{patient_id}:{iso}:{specialty}"
    c = _db()
    replay = c.execute("SELECT response_json FROM calendar_tool_idempotency WHERE idempotency_key=?", (key,)).fetchone()
    if replay:
        c.close()
        import json
        return {**json.loads(replay["response_json"]), "idempotent_replay": True}
    _approved(c, approval_id)
    if not c.execute("SELECT 1 FROM patients WHERE id=?", (patient_id,)).fetchone():
        c.close(); raise ValueError("Synthetic patient not found.")
    if dt <= datetime.now(timezone.utc):
        c.close(); raise ValueError("Booking time must be in the future.")
    if not _slot_is_free(c, iso):
        c.close(); raise ValueError("Requested slot is no longer available.")
    appt_id = "AP-" + uuid.uuid4().hex[:8].upper()
    c.execute("INSERT INTO appointments VALUES(?,?,?,?,?,?,?)",
              (appt_id, patient_id, specialty, appointment_type, iso, "booked", datetime.now(timezone.utc).isoformat()))
    response = {"appointment_id": appt_id, "patient_id": patient_id, "specialty": specialty, "starts_at": iso, "status": "booked"}
    import json
    c.execute("INSERT INTO calendar_tool_idempotency VALUES(?,?,?,?)",
              (key, "calendar_book_appointment", json.dumps(response), datetime.now(timezone.utc).isoformat()))
    c.commit(); c.close()
    return response

def calendar_reschedule_appointment(appointment_id, new_starts_at, approval_id, idempotency_key=None):
    dt = _parse_dt(new_starts_at); iso = dt.isoformat()
    if dt <= datetime.now(timezone.utc):
        raise ValueError("New appointment time must be in the future.")
    key = idempotency_key or f"move:{appointment_id}:{iso}"
    c = _db()
    replay = c.execute("SELECT response_json FROM calendar_tool_idempotency WHERE idempotency_key=?", (key,)).fetchone()
    if replay:
        c.close()
        import json
        return {**json.loads(replay["response_json"]), "idempotent_replay": True}
    _approved(c, approval_id)
    row = c.execute("SELECT * FROM appointments WHERE id=? AND status='booked'", (appointment_id,)).fetchone()
    if not row:
        c.close(); raise ValueError("Active appointment not found.")
    if not _slot_is_free(c, iso, exclude_id=appointment_id):
        c.close(); raise ValueError("Requested slot is no longer available.")
    old = row["starts_at"]
    c.execute("UPDATE appointments SET starts_at=? WHERE id=?", (iso, appointment_id))
    response = {"appointment_id": appointment_id, "previous_starts_at": old, "starts_at": iso, "status": "rescheduled"}
    import json
    c.execute("INSERT INTO calendar_tool_idempotency VALUES(?,?,?,?)",
              (key, "calendar_reschedule_appointment", json.dumps(response), datetime.now(timezone.utc).isoformat()))
    c.commit(); c.close()
    return response

def calendar_cancel_appointment(appointment_id, approval_id, idempotency_key=None):
    key = idempotency_key or f"cancel:{appointment_id}"
    c = _db()
    replay = c.execute("SELECT response_json FROM calendar_tool_idempotency WHERE idempotency_key=?", (key,)).fetchone()
    if replay:
        c.close()
        import json
        return {**json.loads(replay["response_json"]), "idempotent_replay": True}
    _approved(c, approval_id)
    row = c.execute("SELECT * FROM appointments WHERE id=? AND status='booked'", (appointment_id,)).fetchone()
    if not row:
        c.close(); raise ValueError("Active appointment not found.")
    c.execute("UPDATE appointments SET status='cancelled' WHERE id=?", (appointment_id,))
    response = {"appointment_id": appointment_id, "previous_status": "booked", "status": "cancelled"}
    import json
    c.execute("INSERT INTO calendar_tool_idempotency VALUES(?,?,?,?)",
              (key, "calendar_cancel_appointment", json.dumps(response), datetime.now(timezone.utc).isoformat()))
    c.commit(); c.close()
    return response

TOOL_FUNCTIONS = {
    "calendar_find_available_slots": calendar_find_available_slots,
    "calendar_get_appointment": calendar_get_appointment,
    "calendar_book_appointment": calendar_book_appointment,
    "calendar_reschedule_appointment": calendar_reschedule_appointment,
    "calendar_cancel_appointment": calendar_cancel_appointment
}
